<?php
// Incluir la conexión a la base de datos
require_once dirname(__DIR__) . '/db.php';

// Inicializar variables
$matricula = '';
$nombre = '';

// Verificar si se reciben datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y sanitizar los datos del formulario
    $matricula = htmlspecialchars($_POST['matricula']);
    $nombre = htmlspecialchars($_POST['nombre']);

    // Validar y guardar en la base de datos
    try {
        // Ajustar la ruta de la base de datos
        $dbPath = dirname(__DIR__) . '/db/DBfacturacion.sqlite';
        echo "Ruta de la base de datos: " . $dbPath . "<br>";

        // Crear instancia de la base de datos
        $db = new Database($dbPath);
        $pdo = $db->getPDO();

        // Preparar la consulta SQL
        $stmt = $pdo->prepare('INSERT INTO clientes (matricula, nombre) VALUES (:matricula, :nombre)');
        $stmt->bindParam(':matricula', $matricula);
        $stmt->bindParam(':nombre', $nombre);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "Cliente guardado con éxito.<br>";
            // Redireccionar a la página de clientes después de guardar
            header('Location: ../cliente.php');
            exit;
        } else {
            echo "Error al guardar el cliente.<br>";
        }
    } catch (PDOException $e) {
        echo "Error de conexión: " . $e->getMessage() . "<br>";
    }
}
